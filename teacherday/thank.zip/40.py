import turtle as t
import time,random
t.setup(1100,600)
t.bgpic("背景.gif")
t.addshape("feiyuwan.gif")
t.addshape("feiyuwan2.gif")
fei1=t.Turtle()
fei1.shape("feiyuwan.gif")
fei1.up()
fei1.goto(275,250)
fei2=t.Turtle()
fei2.shape("feiyuwan2.gif")
fei2.up()
fei2.goto(-275,250)
t.tracer(0)
def fireworks(angle,x,y):
    colorList=["red","blue","green","cyan","yellow","orange"]
    color=random.choice(colorList)
    
    w=t.Turtle()
    w.pencolor(color)
    w.pensize(5)
    w.penup()
    w.goto(x,y)
    w.down()
    w.setheading(angle)
    for i in range(50):
        w.forward(2)      
        time.sleep(0.0002)
        t.update()
    w.clear()
    w.hideturtle()
    x=w.xcor()
    y=w.ycor()
    tList=[]
    for i in range(20):
        t2=t.Turtle()
        t2.color(color)
        t2.setheading(i*18)
        t2.up()
        t2.goto(x,y)
        t2.forward(30)
        tList.append(t2)
    t.update()
    for j in range(50):
        for i in tList:
            i.forward(5)
        time.sleep(0.01)
        t.update()
    for t2 in tList:
        t2.hideturtle()
    t.update()
posList=[[45,-175,-30],[90,-90,30],[90,0,50],[90,90,30],[135,150,-35]]
while True:
    pos=random.choice(posList)
    fireworks(pos[0],pos[1],pos[2])


